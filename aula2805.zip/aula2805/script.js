// Função para mudar o texto do parágrafo
function mudarTexto() {
  document.getElementById("texto").innerText =
    "Você clicou no botão e o texto mudou! 😎";
}

// Função para mudar a cor de fundo do site
function mudarCor() {
  // Lista de cores possíveis
  const cores = ["#f0f8ff", "#ffe4e1", "#e6ffe6", "#fffacd", "#dcdcdc"];

  // Gera um número aleatório
  const corAleatoria = cores[Math.floor(Math.random() * cores.length)];

  // Aplica a cor no fundo
  document.body.style.backgroundColor = corAleatoria;
}

// Função que mostra um alerta na tela
function mostrarAlerta() {
  alert("Isso é um alerta JavaScript! ⚠️");
}

// Variável para contar os cliques
let contador = 0;

// Função que soma +1 no contador a cada clique
function contarCliques() {
  contador++;
  document.getElementById("contador").innerText =
    "Número de cliques: " + contador;
}
